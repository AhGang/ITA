# 语义化 HTML 基础 

## 要求
- 目标页面：本项目中的[UML_testing.pdf](https://github.com/twschool-full-stack-bootcamp/html_homework/tree/master/UML_testing.pdf)文件

- 使用HTML标签实现目标页面。样式不作要求，功能实现即可。

- 将代码写在项目中index.html文件中

- 作业提交自己的github仓库地址，完成练习。
