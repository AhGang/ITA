public class Tiger extends Cat {
    public Tiger(int age, int weight) {
        super(age, weight);
    }

};
