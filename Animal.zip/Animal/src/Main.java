public class Main {
    public static void main(String[] args) {
        Tiger tiger = new Tiger(2, 18);
        tiger.miao();
    }
}
