public class Cat extends Animal{
    public Cat(int age, int weight) {
        super(age, weight);
    }
    public void miao() {
        System.out.println("喵喵叫");
    }
}
