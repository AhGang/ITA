class Bill{
    private double billMoney;//优惠后的总额
    private double balance;//差额
    private String salePromotionType;//优惠类型

    public Bill() {
    }

    public Bill(double billMoney, double balance, String salePromotionType) {
        this.billMoney = billMoney;
        this.balance = balance;
        this.salePromotionType = salePromotionType;
    }

    public double getBillMoney() {
        return billMoney;
    }

    public void setBillMoney(double billMoney) {
        this.billMoney = billMoney;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getSalePromotionType() {
        return salePromotionType;
    }

    public void setSalePromotionType(String salePromotionType) {
        this.salePromotionType = salePromotionType;
    }
}