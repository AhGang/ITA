class Order{
    private Item item;
    private double OrderSum;//菜品总额
    private int num;//菜品数量
    private boolean isDiscount=false;//是否是半价商品

    public Order() {
    }

    public Order(Item item, int num) {
        this.item = item;
        this.num = num;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public double getOrderSum() {
        return OrderSum;
    }

    public void setOrderSum(double orderSum) {
        this.OrderSum = orderSum;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public boolean isDiscount() {
        return isDiscount;
    }

    public void setDiscount(boolean discount) {
        isDiscount = discount;
    }
}