//实现以下功能：将一个字符串逆序输出
console.log('第一题：');
function reverseString(message){
    var stack = [];
    for(var len = message.length,i=len;i>=0;i-- ){
        stack.push(message[i]);
    }
    return stack.join('');
}
console.log(reverseString('hello')); // should return 'olleh'
//实现以下功能：判断一个字符串是否是回文串。（回文，一个字符串从前面读和从后面读都一样，例如：abcba就是回文串。）
console.log('第二题：');
function palindrome(message){
    var len = message.length;
    var str = "";
    for(var i = len-1; i >= 0;i--){
        str += message[i];
    }
    console.log(str == message)
}
palindrome('hello'); // should return false
palindrome('abcba'); // should return true
//实现以下功能：按字母表顺序输出传入的参数字符串。
console.log('第三题：');
function alphabetSort(message){
    var array = message.split('');
    var temp;
    for(var i=0;i<array.length;i++){
        for(var j=i+1;j<array.length;j++){
            if(array[i]>array[j]){
                temp=array[i];
                array[i]=array[j];
                array[j]=temp;
            }
        }
    }
    console.log(array.join(''))
}
alphabetSort('hello') // should return 'ehllo'
//实现以下功能：计算出一个字符串共有多少个单词组成。
console.log('第四题：');
function countWords(message){
    var array  = message.split(" ");
    console.log(array.length)
}
countWords('Good morning, I love JavaScript.'); // should return 5


