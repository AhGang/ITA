
public class Main {

    public static void main(String[] args) {
        Student student = new Student();
        student.setName("zhangsan");
        student.setStudentNumber(150103);
        student.setSex("Male");
        student.setAge(15);
        System.out.println(student.printStudent());
    }
}